Manual LANI21 is also valid for LANI20.

