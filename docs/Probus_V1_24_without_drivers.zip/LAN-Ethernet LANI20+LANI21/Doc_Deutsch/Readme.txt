Beschreibung LANI21 ist auch f�r LANI20 g�ltig.
